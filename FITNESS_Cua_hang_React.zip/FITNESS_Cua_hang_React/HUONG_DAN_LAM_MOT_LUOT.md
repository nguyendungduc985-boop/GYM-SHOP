# FITNESS — Hướng dẫn làm trọn một lượt

Bộ này gồm toàn bộ mã nguồn React và tài liệu Word 6 trang. Bạn tự copy, chạy, đọc và sửa code. Không cần tạo lại dự án bằng Vite. Bản gốc của bạn chưa bị sửa.

## 1. Sao lưu trước khi thay code

Trong Finder, mở `/Users/dung/Documents/CODE/react/`, sao chép thư mục `gym-management` thành `gym-management-backup`. Đây là bản sao code, không phải bản sao dữ liệu trình duyệt.

Dữ liệu đã nhập nằm trong Chrome: mở web cũ, bấm F12 hoặc Command + Option + I → Application → Local Storage → đúng địa chỉ đang chạy. Sao chép giá trị của `fitness-members`, `fitness-bookings` và các khóa khác bạn cần giữ ra file văn bản. Không bấm Clear site data.

## 2. Mở toàn bộ code để sao chép

Mở `FITNESS_CODE_DE_COPY.html` bằng Chrome. Trang này có hướng dẫn và nút **Sao chép toàn bộ file** cho từng file. Mỗi khối chứa file hoàn chỉnh, không có dấu ba chấm bỏ sót code.

Mở dự án `gym-management` trong VS Code. Với từng file bên dưới: tạo nếu chưa có; nếu đã có, bấm Command + A rồi dán đè toàn bộ nội dung mới và Command + S. Không dán nối dưới code cũ vì sẽ trùng tên biến, component và export.

Cây thư mục sau khi hoàn thành:

```text
gym-management/
├── index.html
├── package.json
├── package-lock.json
├── vite.config.js
├── public/
│   └── images/
│       └── qr-thanh-toan.png   ← ảnh QR của chính bạn
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── App.css
    ├── index.css
    ├── data.js
    ├── shopLogic.js
    ├── storage.js
    ├── components/
    │   ├── Header.jsx
    │   ├── MemberList.jsx
    │   ├── ProductArt.jsx
    │   └── ProductCard.jsx
    └── pages/
        ├── Home.jsx
        ├── Shop.jsx
        ├── ProductDetail.jsx
        ├── Cart.jsx
        ├── Packages.jsx
        ├── Schedule.jsx
        ├── Checkout.jsx
        ├── Orders.jsx
        ├── OrderDetail.jsx
        └── NotFound.jsx
```

Đường dẫn trong cây tính từ thư mục dự án. Thứ tự dễ học: data.js → shopLogic.js → storage.js → components → pages → App.jsx → CSS → main.jsx. Trình duyệt có thể báo lỗi trong lúc bạn chưa dán đủ file; dán đủ rồi mới kiểm tra.

Các file About.jsx, Payment.jsx hay component cũ khác nếu còn trong dự án thì có thể để lại; App mới không import chúng. `/gioi-thieu` chuyển về trang chủ; phần thuyết trình nằm trong Word.

Nếu muốn chạy ngay để xem trước: giải nén ZIP, mở thư mục `fitness-shop` bằng VS Code rồi chạy lệnh ở bước 5. Trong ZIP đã có tất cả file đúng vị trí; không cần copy từ trang HTML. Bạn chỉ cần chọn một trong hai cách.

## 3. Thêm ảnh QR nhận tiền của bạn

Trong app ngân hàng, lấy ảnh QR nhận tiền của đúng tài khoản. Lưu ảnh PNG tên `qr-thanh-toan.png`. Tạo thư mục `public/images` rồi đặt ảnh vào đó. Đường dẫn trên dự án hiện tại của bạn là:

`/Users/dung/Documents/CODE/react/gym-management/public/images/qr-thanh-toan.png`

Trong JSX, địa chỉ ảnh là `/images/qr-thanh-toan.png`, không có chữ public. Nếu ảnh gốc là JPG thì dùng tên .jpg và sửa src trong OrderDetail.jsx cho khớp; đổi đuôi file không tự chuyển định dạng ảnh.

Bộ code không kèm QR tài khoản người khác. Khi thiếu ảnh, trang sẽ hiện “Chưa có ảnh QR nhận tiền”. QR tĩnh không tự cập nhật số tiền hay mã đơn; người chuyển cần nhập đúng tổng và nội dung đang hiển thị. Kiểm tra tên người nhận trong ứng dụng ngân hàng trước khi chuyển.

Luồng hiện tại: lưu đơn → hiển thị QR → khách báo đã chuyển → nhân viên đối chiếu tiền nhận được. Nút “Tôi đã chuyển khoản” chỉ lưu thông báo trên máy khách, không xác nhận tiền và không gửi thông báo cho nhân viên.

## 4. Cập nhật hàng hóa và thông tin thực tế

Mở `src/data.js`. Mảng `products` chứa hàng hóa, mảng `packages` chứa gói tập. Sửa tên, giá, mô tả và quyền lợi theo phòng tập của bạn. Giá là số nguyên đồng, ví dụ `149000`, không viết `149.000`.

Các sản phẩm đang có minh họa SVG: bình nước, tạ tay, thảm yoga, túi, dây nhảy, khăn. Đây là hình vẽ, chưa phải ảnh chụp hàng của bạn. Để dùng ảnh thật, đặt ảnh vào `public/images`, rồi thêm thuộc tính sau trong object sản phẩm tương ứng:

```js
image: "/images/binh-nuoc.jpg",
```

ProductArt sẽ dùng ảnh khi có thuộc tính image, nếu không thì dùng hình SVG. Giữ id ổn định để giỏ cũ còn tìm được sản phẩm. `maxQuantity: 10` là giới hạn mỗi mặt hàng trong một đơn, chưa phải số tồn kho và không có nghiệp vụ trừ kho.

Sửa thương hiệu/lời giới thiệu ở Header.jsx, Home.jsx và footer của App.jsx. Sửa màu chủ đạo ở App.css. Sửa danh mục lớp ở Schedule.jsx. Lịch lớp hiện là lịch lặp tuần, chưa chia theo ngày tháng.

## 5. Cài thư viện và chạy

Nếu dùng dự án cũ, trong terminal chạy lần lượt:

```bash
cd /Users/dung/Documents/CODE/react/gym-management
npm install
npm run dev
```

Nếu dùng thư mục giải nén, mở Terminal trong VS Code tại chính thư mục `fitness-shop` rồi chạy hai dòng cuối. Không chạy lệnh npm ở ngoài thư mục có package.json. React đã nằm trong dependencies; không cần cài React toàn cục.

Nếu chạy bản giải nén mới, cần có Node.js và npm. Kiểm tra bằng `node -v` và `npm -v`. Với Vite trong bộ này, dùng Node 22.12 trở lên hoặc Node 24. Nếu máy bạn đang chạy được dự án cũ, có thể dùng tiếp môi trường hiện tại.

Mở đúng địa chỉ terminal hiển thị. Để thấy dữ liệu cũ, dùng cùng trình duyệt, cùng giao thức, hostname và port như trước. `http://localhost:5173` và `http://127.0.0.1:5173` là hai nơi lưu khác nhau; đổi sang port 5174 cũng vậy. Dừng terminal web cũ bằng Control + C trước nếu muốn dùng lại port 5173.

Kiểm tra bản build:

```bash
npm run build
```

Bộ ZIP có package-lock.json. Có thể dùng `npm ci` thay cho `npm install` ở bản giải nén để cài đúng lockfile. Không copy thư mục node_modules từ nơi khác.

## 6. Thử hết chức năng trong một lượt

1. Trang chủ: kiểm tra menu, sản phẩm nổi bật và các nút đến cửa hàng/gói tập.
2. Cửa hàng: tìm “bình”, lọc Dụng cụ, chọn giá tăng dần, tải lại để kiểm tra bộ lọc còn trên URL.
3. Chi tiết: mở một sản phẩm, xem `/cua-hang/bottle`, thêm vào giỏ.
4. Giỏ: thêm hai bình nước; với giá ban đầu tổng là 298.000 đồng. Tăng, giảm, xóa; số lượng tối đa mỗi loại là 10.
5. Thanh toán: nhập tên và số điện thoại bắt đầu bằng 0 đủ 10 chữ số; thử nhập sai để thấy thông báo. Bấm lưu đơn. Không cần chuyển tiền để kiểm tra giao diện.
6. Chi tiết đơn: thấy mã đơn, tổng tiền, QR của bạn; tải thông tin đơn thành TXT. Tải lại trang để kiểm tra đơn còn.
7. Bấm báo đã chuyển: trạng thái phải là khách báo chuyển, chưa xác minh. Đơn chưa báo có thể hủy yêu cầu local; đây không phải chức năng hoàn tiền.
8. Gói tập: chọn Plus, kiểm tra tổng 900.000 đồng theo cấu hình ban đầu. Đặt gói không làm mất giỏ hàng hóa.
9. Hội viên: thêm, tìm, sửa gói, xóa. MemberList nhận members/setMembers bằng props, không khai báo lại state cùng tên.
10. Lịch tập: chọn hội viên, đăng ký lớp, thử đăng ký trùng; xóa hội viên thì các đăng ký liên quan cũng được dọn.
11. Sandbox: bật ở cuối trang, thử thay đổi dữ liệu và chuyển trang bằng menu. Thanh toán thật bị chặn. Thoát sẽ khôi phục dữ liệu trước đó. Tải lại trình duyệt sẽ thoát Sandbox vì chế độ này chỉ nằm trong state.
12. Thu nhỏ cửa sổ hoặc dùng chế độ điện thoại của DevTools để kiểm tra menu, form và bảng.

## 7. Đọc code để trả lời thầy

- data.js: danh mục local; phân biệt dữ liệu khai báo trong file và dữ liệu được người dùng nhập.
- storage.js: tên khóa localStorage, JSON.parse/JSON.stringify, kiểm tra dữ liệu và xử lý lỗi.
- App.jsx: useState, useEffect, truyền props, dùng chung dữ liệu giữa các route, Sandbox.
- MemberList.jsx: biểu mẫu, thêm/sửa/xóa, map, filter, key.
- shopLogic.js: cập nhật số lượng bất biến và tính tổng bằng reduce.
- Shop.jsx: useSearchParams cho tìm kiếm/lọc/sắp xếp.
- ProductDetail.jsx và OrderDetail.jsx: useParams lấy id từ URL.
- Checkout.jsx: kiểm tra form, lưu đơn thành công rồi useNavigate.
- Header.jsx: NavLink và menu active.

Word gồm bài nói, bảng chức năng, luồng dữ liệu, kiến thức React, toàn bộ route và 9 câu hỏi đáp. Đọc trang 1 để giới thiệu; dùng các trang sau khi giải thích code. Không cần PowerPoint.

Sandbox trong code là chế độ dữ liệu thử trong ứng dụng; không phải nền tảng CodeSandbox hoặc sandbox của cổng thanh toán. Việc thầy cộng điểm tùy yêu cầu môn học, không thể bảo đảm chỉ bằng việc đặt tên nút Sandbox.

## 8. Dữ liệu lỗi hoặc không thấy dữ liệu cũ

Trước hết kiểm tra đúng địa chỉ web và đúng profile Chrome. Nếu hiện “Không đọc được dữ liệu”, chương trình ngừng tự ghi đè bản cũ. Mở DevTools → Application → Local Storage, sao lưu nguyên giá trị khóa được báo lỗi. Sửa dữ liệu JSON đúng cấu trúc hoặc khôi phục bản sao đã lưu, rồi tải lại.

Chỉ xóa riêng khóa lỗi khi bạn đã sao lưu và chấp nhận bỏ dữ liệu trong khóa đó. Không xóa toàn bộ localStorage để xử lý một lỗi. Nếu JSON hợp lệ nhưng sai cấu trúc, so với các hàm kiểm tra trong storage.js.

## 9. Phạm vi của phiên bản này

Đây là ứng dụng React chạy được với lưu trữ local, có luồng đặt hàng và hướng dẫn chuyển khoản. Không có Supabase, backend, đăng nhập, phân quyền hay đồng bộ đơn giữa khách và người bán. Nhân viên cần nhận thông tin đơn từ khách và kiểm tra ngân hàng. Chưa tự kích hoạt gói hoặc quản lý tồn kho.

Mã đã build thành công bằng Vite và đạt 16 kiểm tra logic dữ liệu/giỏ hàng. Trình duyệt tự động không khởi chạy được trong môi trường tạo bộ code; các bước kiểm tra giao diện ở mục 6 cần thực hiện trên máy bạn. File Word đã được render và kiểm tra đủ 6 trang.
