import { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, Navigate, Link } from "react-router-dom";
import Header from "./components/Header";
import MemberList from "./components/MemberList";
import Home from "./pages/Home";
import Shop from "./pages/Shop";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import Packages from "./pages/Packages";
import Schedule from "./pages/Schedule";
import Checkout from "./pages/Checkout";
import Orders from "./pages/Orders";
import OrderDetail from "./pages/OrderDetail";
import NotFound from "./pages/NotFound";
import { products } from "./data";
import {
  changeQuantity,
  getCheckoutLines,
  orderTotal,
  validateCustomer,
} from "./shopLogic";
import {
  readLocalData,
  writeLocalData,
  writeShopData,
  createSampleData,
} from "./storage";
import "./App.css";

export default function App() {
  const [initial] = useState(readLocalData);
  const [data, setData] = useState(initial.data);
  const [storageError, setStorageError] = useState(initial.error);
  const [sandbox, setSandbox] = useState(false);
  const [originalData, setOriginalData] = useState(null);
  const [viewVersion, setViewVersion] = useState(0);

  // DỮ LIỆU LOCAL: effect lưu khi dữ liệu thay đổi, bỏ qua Sandbox.
  // Nếu đọc dữ liệu cũ bị lỗi, không tự ghi đè bản cũ.
  useEffect(() => {
    if (sandbox || initial.error) return;
    try {
      writeLocalData(data);
      setStorageError("");
    } catch {
      setStorageError(
        "Không lưu được dữ liệu. Thay đổi có thể mất khi tải lại trang. Kiểm tra dung lượng và quyền lưu của trình duyệt.",
      );
    }
  }, [data, sandbox, initial.error]);

  // Giữ giao diện props của MemberList cũ. Xóa hội viên và đăng ký liên quan cùng một lần cập nhật.
  function setMembers(update) {
    setData((previous) => {
      const members =
        typeof update === "function" ? update(previous.members) : update;
      return {
        ...previous,
        members,
        bookings: previous.bookings.filter((b) =>
          members.some((m) => m.id === b.memberId),
        ),
      };
    });
  }
  function setBookings(update) {
    setData((previous) => ({
      ...previous,
      bookings:
        typeof update === "function" ? update(previous.bookings) : update,
    }));
  }
  function onAdd(productId) {
    const product = products.find((p) => p.id === productId);
    if (!product) return { ok: false, message: "Sản phẩm không tồn tại." };
    const quantity =
      data.cart.find((i) => i.productId === productId)?.quantity || 0;
    if (quantity >= product.maxQuantity)
      return {
        ok: false,
        message:
          "Đã đạt giới hạn " +
          product.maxQuantity +
          " sản phẩm cùng loại mỗi đơn.",
      };
    setData((previous) => {
      const current =
        previous.cart.find((i) => i.productId === productId)?.quantity || 0;
      return {
        ...previous,
        cart: changeQuantity(previous.cart, productId, current + 1),
      };
    });
    return { ok: true, message: "Đã thêm " + product.name + " vào giỏ hàng." };
  }
  function onQuantity(id, quantity) {
    setData((previous) => ({
      ...previous,
      cart: changeQuantity(previous.cart, id, quantity),
    }));
  }
  function onCreateOrder(customer, packageId) {
    if (sandbox)
      return { ok: false, message: "Thoát Sandbox trước khi tạo đơn." };
    if (initial.error) return { ok: false, message: initial.error };
    const error = validateCustomer(customer);
    if (error) return { ok: false, message: error };
    const items = getCheckoutLines(data.cart, packageId);
    if (!items.length)
      return {
        ok: false,
        message: "Giỏ hàng trống hoặc gói tập không hợp lệ.",
      };
    const order = {
      id:
        "FIT" +
        crypto.randomUUID().replaceAll("-", "").slice(0, 12).toUpperCase(),
      createdAt: new Date().toISOString(),
      kind: packageId ? "package" : "products",
      customer: {
        name: customer.name.trim(),
        phone: customer.phone.trim(),
        note: customer.note.trim(),
      },
      // Lưu bản sao tên và giá tại thời điểm đặt để sau này đổi bảng giá không làm đổi đơn cũ.
      items,
      total: orderTotal(items),
      status: "awaiting_transfer",
    };
    const orders = [...data.orders, order];
    const cart = packageId ? data.cart : [];
    try {
      writeShopData(cart, orders);
    } catch {
      return {
        ok: false,
        message:
          "Không lưu được đơn. Giỏ hàng được giữ nguyên; chưa có đơn mới.",
      };
    }
    setData((previous) => ({ ...previous, cart, orders }));
    return { ok: true, id: order.id };
  }
  function onStatus(id, status) {
    if (sandbox || initial.error)
      return {
        ok: false,
        message: "Không thể cập nhật đơn trong chế độ hiện tại.",
      };
    const order = data.orders.find((o) => o.id === id);
    if (
      !order ||
      order.status !== "awaiting_transfer" ||
      !["customer_reported", "cancelled"].includes(status)
    )
      return { ok: false, message: "Trạng thái không cho phép thao tác này." };
    const orders = data.orders.map((o) => (o.id === id ? { ...o, status } : o));
    try {
      writeShopData(data.cart, orders);
    } catch {
      return {
        ok: false,
        message: "Không lưu được trạng thái. Dữ liệu chưa thay đổi.",
      };
    }
    setData((previous) => ({ ...previous, orders }));
    return {
      ok: true,
      message:
        status === "cancelled"
          ? "Đã hủy yêu cầu trên thiết bị này."
          : "Đã lưu thông báo chuyển khoản của bạn; chưa có xác minh từ ngân hàng.",
    };
  }
  function toggleSandbox() {
    if (sandbox) {
      if (!window.confirm("Thoát Sandbox và bỏ các thay đổi thử?")) return;
      setData(originalData);
      setOriginalData(null);
      setSandbox(false);
    } else {
      setOriginalData(structuredClone(data));
      setData(createSampleData());
      setSandbox(true);
    }
    setViewVersion((v) => v + 1);
  }
  function resetSandbox() {
    if (sandbox && window.confirm("Làm lại toàn bộ dữ liệu thử?")) {
      setData(createSampleData());
      setViewVersion((v) => v + 1);
    }
  }
  const cartCount = data.cart.reduce((total, item) => total + item.quantity, 0);
  return (
    <BrowserRouter>
      <Header cartCount={cartCount} />
      <main className="main-content">
        {sandbox && (
          <p className="sandbox-banner" role="status">
            SANDBOX · Dữ liệu thử, không ghi vào localStorage. Thanh toán thật
            đang tắt.
          </p>
        )}
        {!sandbox && storageError && (
          <p className="error-banner" role="alert">
            {storageError}
          </p>
        )}
        <Routes key={viewVersion}>
          <Route path="/" element={<Home onAdd={onAdd} />} />
          <Route path="/cua-hang" element={<Shop onAdd={onAdd} />} />
          <Route
            path="/cua-hang/:id"
            element={<ProductDetail onAdd={onAdd} />}
          />
          <Route
            path="/gio-hang"
            element={
              <Cart
                cart={data.cart}
                onQuantity={onQuantity}
                sandbox={sandbox}
              />
            }
          />
          <Route path="/goi-tap" element={<Packages />} />
          <Route
            path="/hoi-vien"
            element={
              <MemberList members={data.members} setMembers={setMembers} />
            }
          />
          <Route
            path="/lich-tap"
            element={
              <Schedule
                members={data.members}
                bookings={data.bookings}
                setBookings={setBookings}
              />
            }
          />
          <Route
            path="/thanh-toan"
            element={
              <Checkout
                cart={data.cart}
                onCreateOrder={onCreateOrder}
                sandbox={sandbox}
              />
            }
          />
          <Route path="/don-hang" element={<Orders orders={data.orders} />} />
          <Route
            path="/don-hang/:id"
            element={
              <OrderDetail
                orders={data.orders}
                onStatus={onStatus}
                sandbox={sandbox}
              />
            }
          />
          <Route
            path="/members"
            element={<Navigate to="/hoi-vien" replace />}
          />
          <Route path="/gioi-thieu" element={<Navigate to="/" replace />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="footer">
        <div className="footer-main">
          <div>
            <Link className="brand" to="/">
              FITNESS<span className="brand-dot">.</span>
            </Link>
            <p>
              Tập luyện đều đặn.
              <br />
              Chăm sóc bản thân mỗi ngày.
            </p>
          </div>
          <div>
            <span className="eyebrow">KHÁM PHÁ</span>
            <Link to="/cua-hang">Cửa hàng</Link>
            <Link to="/goi-tap">Gói tập</Link>
            <Link to="/lich-tap">Lịch tập</Link>
          </div>
          <div>
            <span className="eyebrow">ĐƠN HÀNG</span>
            <Link to="/gio-hang">Giỏ hàng</Link>
            <Link to="/don-hang">Đơn trên thiết bị này</Link>
            <p>Nhận hàng tại phòng tập.</p>
          </div>
        </div>
        <div className="footer-bottom">
          <span>FITNESS © 2026</span>
          <div className="sandbox-controls">
            <span>
              {sandbox ? "Đang thử dữ liệu" : "Dữ liệu lưu trên trình duyệt"}
            </span>
            {sandbox && (
              <button onClick={resetSandbox}>Làm lại dữ liệu thử</button>
            )}
            <button onClick={toggleSandbox}>
              {sandbox ? "Thoát Sandbox" : "Bật Sandbox"}
            </button>
          </div>
        </div>
      </footer>
    </BrowserRouter>
  );
}
