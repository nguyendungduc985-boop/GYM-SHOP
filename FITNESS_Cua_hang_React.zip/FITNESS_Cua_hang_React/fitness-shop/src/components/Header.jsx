import { NavLink, Link } from "react-router-dom";
export default function Header({ cartCount }) {
  return (
    <>
      <div className="announcement">
        FITNESS STUDIO <span>Không gian tập luyện & phụ kiện thể thao</span>
      </div>
      <header className="header">
        <Link className="brand" to="/" aria-label="FITNESS trang chủ">
          <span className="brand-icon">F</span>FITNESS
          <span className="brand-dot">.</span>
        </Link>
        <nav className="main-nav" aria-label="Menu chính">
          <NavLink to="/" end>
            Trang chủ
          </NavLink>
          <NavLink to="/cua-hang">Cửa hàng</NavLink>
          <NavLink to="/goi-tap">Gói tập</NavLink>
          <NavLink to="/lich-tap">Lịch tập</NavLink>
          <NavLink to="/hoi-vien">Hội viên</NavLink>
          <NavLink to="/don-hang">Đơn hàng</NavLink>
        </nav>
        <Link className="cart-link" to="/gio-hang">
          Giỏ hàng <span>{cartCount}</span>
        </Link>
      </header>
    </>
  );
}
