import { useState } from "react";
import { useSearchParams } from "react-router-dom";

function MemberList({ members, setMembers }) {
  // STATE CỦA BIỂU MẪU
  const [name, setName] = useState("");
  const [packageName, setPackageName] = useState("Basic");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  // null: đang thêm mới.
  // Có id: đang sửa hội viên mang id đó.
  const [editingId, setEditingId] = useState(null);

  // BỘ LỌC ĐƯỢC LƯU TRÊN URL
  const [searchParams, setSearchParams] = useSearchParams();

  const search = searchParams.get("q") || "";
  const packageParam = searchParams.get("goi") || "all";

  // Nếu URL chứa gói không hợp lệ, hiển thị tất cả.
  const packageFilter = ["Basic", "Plus", "Pro"].includes(packageParam)
    ? packageParam
    : "all";

  // CẬP NHẬT MỘT BỘ LỌC TRÊN URL
  function updateFilter(key, value) {
    // Sao chép để giữ lại các tham số khác.
    const newParams = new URLSearchParams(searchParams);

    if (value === "" || value === "all") {
      newParams.delete(key);
    } else {
      newParams.set(key, value);
    }

    // replace giúp tránh tạo một mục lịch sử cho mỗi ký tự nhập.
    setSearchParams(newParams, { replace: true });
  }

  function clearFilters() {
    const newParams = new URLSearchParams(searchParams);

    newParams.delete("q");
    newParams.delete("goi");

    setSearchParams(newParams, { replace: true });
  }

  // ĐƯA BIỂU MẪU VỀ CHẾ ĐỘ THÊM MỚI
  function resetForm() {
    setName("");
    setPackageName("Basic");
    setEditingId(null);
    setError("");
  }

  // THÊM MỚI HOẶC LƯU THAY ĐỔI
  function handleSubmit(event) {
    event.preventDefault();

    const cleanName = name.trim();

    if (cleanName.length < 2) {
      setError("Vui lòng nhập họ tên có ít nhất 2 ký tự.");
      return;
    }

    if (editingId !== null) {
      // Sửa đúng hội viên có id đang được chọn.
      setMembers((previousMembers) =>
        previousMembers.map((member) =>
          member.id === editingId
            ? {
                ...member,
                name: cleanName,
                packageName: packageName,
              }
            : member,
        ),
      );

      setMessage("Đã cập nhật hội viên.");
    } else {
      const newMember = {
        id: crypto.randomUUID(),
        name: cleanName,
        packageName: packageName,
      };

      setMembers((previousMembers) => [...previousMembers, newMember]);

      setMessage("Đã thêm hội viên mới.");
    }

    resetForm();
  }

  // ĐƯA THÔNG TIN HỘI VIÊN LÊN BIỂU MẪU ĐỂ SỬA
  function handleEditMember(member) {
    setEditingId(member.id);
    setName(member.name);
    setPackageName(member.packageName);
    setError("");
    setMessage("");
  }

  function handleCancelEdit() {
    resetForm();
    setMessage("Đã hủy chỉnh sửa.");
  }

  // XÓA HỘI VIÊN
  function handleDeleteMember(member) {
    const confirmed = window.confirm(
      `Bạn có chắc muốn xóa hội viên "${member.name}" không?`,
    );

    if (!confirmed) {
      return;
    }

    setMembers((previousMembers) =>
      previousMembers.filter((item) => item.id !== member.id),
    );

    // Nếu xóa người đang sửa, xóa luôn nội dung biểu mẫu.
    if (editingId === member.id) {
      resetForm();
    }

    setMessage("Đã xóa hội viên.");
  }

  // LỌC DANH SÁCH ĐỂ HIỂN THỊ
  const filteredMembers = members.filter((member) => {
    const matchesName = member.name
      .toLowerCase()
      .includes(search.trim().toLowerCase());

    const matchesPackage =
      packageFilter === "all" || member.packageName === packageFilter;

    return matchesName && matchesPackage;
  });

  return (
    <section className="members-section">
      <h2>Quản lý hội viên</h2>

      {message && (
        <p className="member-message" role="status">
          {message}
        </p>
      )}

      <form className="member-form" onSubmit={handleSubmit}>
        <h3>
          {editingId !== null ? "Chỉnh sửa hội viên" : "Thêm hội viên mới"}
        </h3>

        <label htmlFor="member-name">Họ và tên</label>

        <input
          id="member-name"
          type="text"
          placeholder="Nhập họ tên hội viên"
          value={name}
          onChange={(event) => setName(event.target.value)}
          maxLength={80}
          required
        />

        <label htmlFor="member-package">Gói tập</label>

        <select
          id="member-package"
          value={packageName}
          onChange={(event) => setPackageName(event.target.value)}
        >
          <option value="Basic">Basic</option>
          <option value="Plus">Plus</option>
          <option value="Pro">Pro</option>
        </select>

        {error && (
          <p className="form-error" role="alert">
            {error}
          </p>
        )}

        <div className="member-form-actions">
          <button type="submit" className="add-member-button">
            {editingId !== null ? "Lưu thay đổi" : "Thêm hội viên"}
          </button>

          {editingId !== null && (
            <button
              type="button"
              className="cancel-member-button"
              onClick={handleCancelEdit}
            >
              Hủy sửa
            </button>
          )}
        </div>
      </form>

      <h3>Danh sách hội viên</h3>

      <div className="member-filters">
        <div className="member-filter-field">
          <label htmlFor="search-member">Tìm theo họ tên</label>

          <input
            id="search-member"
            type="search"
            placeholder="Ví dụ: Minh"
            value={search}
            onChange={(event) => updateFilter("q", event.target.value)}
          />
        </div>

        <div className="member-filter-field">
          <label htmlFor="filter-package">Lọc theo gói tập</label>

          <select
            id="filter-package"
            value={packageFilter}
            onChange={(event) => updateFilter("goi", event.target.value)}
          >
            <option value="all">Tất cả gói tập</option>
            <option value="Basic">Basic</option>
            <option value="Plus">Plus</option>
            <option value="Pro">Pro</option>
          </select>
        </div>

        <button
          type="button"
          className="clear-filter-button"
          onClick={clearFilters}
        >
          Xóa bộ lọc
        </button>
      </div>

      <p className="member-count">
        Hiển thị {filteredMembers.length} / {members.length} hội viên
      </p>

      <div className="members-table-wrapper">
        <table className="members-table">
          <thead>
            <tr>
              <th>STT</th>
              <th>Họ tên</th>
              <th>Gói tập</th>
              <th>Thao tác</th>
            </tr>
          </thead>

          <tbody>
            {filteredMembers.map((member, index) => (
              <tr key={member.id}>
                <td>{index + 1}</td>
                <td>{member.name}</td>
                <td>{member.packageName}</td>

                <td>
                  <div className="member-row-actions">
                    <button
                      type="button"
                      className="edit-member-button"
                      aria-label={`Sửa hội viên ${member.name}`}
                      onClick={() => handleEditMember(member)}
                    >
                      Sửa
                    </button>

                    <button
                      type="button"
                      className="delete-member-button"
                      aria-label={`Xóa hội viên ${member.name}`}
                      onClick={() => handleDeleteMember(member)}
                    >
                      Xóa
                    </button>
                  </div>
                </td>
              </tr>
            ))}

            {filteredMembers.length === 0 && (
              <tr>
                <td colSpan={4} className="empty-members">
                  {members.length === 0
                    ? "Chưa có hội viên. Hãy thêm hội viên mới."
                    : "Không có hội viên phù hợp với bộ lọc."}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

export default MemberList;
