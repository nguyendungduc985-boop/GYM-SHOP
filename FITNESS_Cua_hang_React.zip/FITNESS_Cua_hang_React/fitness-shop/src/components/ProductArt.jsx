// Hình minh họa SVG có sẵn trong code. Đổi sang ảnh sản phẩm thật bằng trường image trong data.js.
export default function ProductArt({ product, className = "" }) {
  if (product.image)
    return (
      <img
        className={"product-photo " + className}
        src={product.image}
        alt={product.name}
      />
    );
  return (
    <div
      className={"product-art " + className}
      style={{ background: product.color }}
    >
      <svg
        viewBox="0 0 320 260"
        role="img"
        aria-label={"Minh họa " + product.name}
      >
        <ellipse
          cx="160"
          cy="224"
          rx="83"
          ry="11"
          fill="#17231b"
          opacity=".1"
        />
        {product.type === "bottle" && (
          <g transform="rotate(-12 160 140)">
            <rect x="126" y="32" width="67" height="29" rx="9" fill="#202820" />
            <path
              d="M136 63 L136 79 Q113 90 113 112 V203 Q113 222 133 222 H188 Q208 222 208 203 V112 Q208 90 184 79 V63"
              fill="#62734a"
            />
            <path
              d="M124 115 V195"
              stroke="#aabd83"
              strokeWidth="7"
              strokeLinecap="round"
            />
            <rect
              x="131"
              y="135"
              width="59"
              height="34"
              rx="5"
              fill="#dce8b4"
            />
            <text
              x="160"
              y="157"
              textAnchor="middle"
              fontSize="11"
              fill="#273522"
              fontWeight="bold"
            >
              FITNESS
            </text>
            <path
              d="M191 41 Q226 38 222 66 Q220 78 201 73"
              fill="none"
              stroke="#202820"
              strokeWidth="9"
            />
          </g>
        )}
        {product.type === "dumbbell" && (
          <g transform="rotate(-28 160 135)">
            <rect
              x="82"
              y="114"
              width="154"
              height="27"
              rx="9"
              fill="#a3a6a2"
            />
            <path d="M112 120H207" stroke="#d0d3cd" strokeWidth="4" />
            <rect
              x="60"
              y="74"
              width="49"
              height="110"
              rx="13"
              fill="#252c28"
            />
            <rect x="42" y="90" width="24" height="77" rx="8" fill="#465048" />
            <rect
              x="213"
              y="74"
              width="49"
              height="110"
              rx="13"
              fill="#252c28"
            />
            <rect x="255" y="90" width="24" height="77" rx="8" fill="#465048" />
            <text
              x="237"
              y="134"
              fontSize="16"
              fill="#dfe4d8"
              textAnchor="middle"
            >
              2 KG
            </text>
          </g>
        )}
        {product.type === "mat" && (
          <g>
            <path d="M48 192L208 85 283 160 120 225Z" fill="#aaa1c1" />
            <path
              d="M77 192L211 103M93 201L226 115M109 210L242 130"
              stroke="#c4bdd6"
              strokeWidth="3"
            />
            <path
              d="M49 185L185 82"
              stroke="#6d6582"
              strokeWidth="52"
              strokeLinecap="round"
            />
            <ellipse
              cx="186"
              cy="83"
              rx="28"
              ry="24"
              transform="rotate(-35 186 83)"
              fill="#bbb2ce"
            />
            <ellipse
              cx="186"
              cy="83"
              rx="17"
              ry="14"
              transform="rotate(-35 186 83)"
              fill="none"
              stroke="#6d6582"
              strokeWidth="5"
            />
          </g>
        )}
        {product.type === "bag" && (
          <g>
            <path d="M87 100H241L264 135V207H60V135Z" fill="#445659" />
            <rect
              x="62"
              y="119"
              width="195"
              height="91"
              rx="20"
              fill="#718386"
            />
            <path
              d="M113 122V79Q159 38 204 79V122"
              fill="none"
              stroke="#293a3d"
              strokeWidth="11"
            />
            <path d="M83 137H235" stroke="#d5dfdc" strokeWidth="3" />
            <path
              d="M97 133V208M222 133V208"
              stroke="#3e5459"
              strokeWidth="12"
            />
            <text
              x="157"
              y="177"
              textAnchor="middle"
              fontWeight="bold"
              fontSize="15"
              fill="#edf1e8"
            >
              FITNESS
            </text>
          </g>
        )}
        {product.type === "rope" && (
          <g>
            <path
              d="M94 183C17 66 185 6 235 73S232 207 181 193S184 87 121 84S59 153 98 164"
              fill="none"
              stroke="#916550"
              strokeWidth="9"
              strokeLinecap="round"
            />
            <rect
              x="81"
              y="151"
              width="29"
              height="77"
              rx="12"
              fill="#262d29"
              transform="rotate(-17 95 190)"
            />
            <rect
              x="171"
              y="156"
              width="29"
              height="76"
              rx="12"
              fill="#262d29"
              transform="rotate(13 185 195)"
            />
          </g>
        )}
        {product.type === "towel" && (
          <g transform="rotate(-10 160 150)">
            <rect
              x="73"
              y="88"
              width="176"
              height="128"
              rx="11"
              fill="#a5ae90"
            />
            <rect
              x="67"
              y="68"
              width="176"
              height="124"
              rx="11"
              fill="#e7e8d9"
            />
            <path
              d="M89 76V183M97 76V183M214 76V183M222 76V183"
              stroke="#c0c8a5"
              strokeWidth="4"
            />
            <text
              x="157"
              y="137"
              textAnchor="middle"
              fill="#84906f"
              fontSize="12"
              fontWeight="bold"
            >
              FITNESS
            </text>
          </g>
        )}
      </svg>
    </div>
  );
}
