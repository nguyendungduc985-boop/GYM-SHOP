import { Link } from "react-router-dom";
import ProductArt from "./ProductArt";
import { money } from "../data";
export default function ProductCard({ product, onAdd }) {
  return (
    <article className="product-card">
      <Link to={"/cua-hang/" + product.id}>
        <ProductArt product={product} />
      </Link>
      <div className="product-card-body">
        <div className="eyebrow">{product.category}</div>
        <Link to={"/cua-hang/" + product.id}>
          <h3>{product.name}</h3>
        </Link>
        <div className="product-bottom">
          <strong>{money(product.price)}</strong>
          <button
            className="round-button"
            aria-label={"Thêm " + product.name + " vào giỏ"}
            onClick={() => onAdd(product.id)}
          >
            +
          </button>
        </div>
      </div>
    </article>
  );
}
