// DANH MỤC LOCAL: sửa tên, giá và mô tả ở đây trước khi sử dụng bán hàng.
// Giá gói tập dùng chung cho trang gói tập và thanh toán, tránh lệch giá.
export const packages = [
  {
    id: "basic",
    name: "Basic",
    months: 1,
    price: 350000,
    description: "Bắt đầu thói quen tập luyện.",
    features: ["Khu tập gym", "Khu cardio", "Tủ đồ trong buổi tập"],
  },
  {
    id: "plus",
    name: "Plus",
    months: 3,
    price: 900000,
    description: "Dành thời gian cho chính mình.",
    features: [
      "Toàn bộ quyền lợi Basic",
      "Lớp tập nhóm",
      "1 buổi hướng dẫn với PT",
    ],
  },
  {
    id: "pro",
    name: "Pro",
    months: 6,
    price: 1600000,
    description: "Theo đuổi mục tiêu dài hạn.",
    features: [
      "Toàn bộ quyền lợi Plus",
      "4 buổi hướng dẫn với PT",
      "Đánh giá thể lực định kỳ",
    ],
  },
];
export const products = [
  {
    id: "bottle",
    name: "Bình nước tập luyện",
    category: "Phụ kiện",
    price: 149000,
    color: "#d9e99b",
    type: "bottle",
    label: "MỖI NGÀY",
    description:
      "Bình nước đồng hành trong những buổi tập. Thiết kế gọn để mang theo trong túi.",
    details: ["Dung tích 700 ml", "Nắp vặn và quai cầm", "Màu xanh olive"],
    maxQuantity: 10,
  },
  {
    id: "dumbbell",
    name: "Tạ tay đôi 2 kg",
    category: "Dụng cụ",
    price: 390000,
    color: "#e9ddd2",
    type: "dumbbell",
    label: "TẬP TẠI NHÀ",
    description:
      "Bộ hai tạ tay cho các bài tập cơ bản tại phòng tập hoặc tại nhà.",
    details: ["Một bộ gồm 2 tạ", "Khối lượng 2 kg mỗi tạ", "Bề mặt bọc cao su"],
    maxQuantity: 10,
  },
  {
    id: "mat",
    name: "Thảm yoga Essential",
    category: "Dụng cụ",
    price: 259000,
    color: "#dfdfec",
    type: "mat",
    label: "GIÃN CƠ",
    description:
      "Thảm cho yoga và các bài tập trên sàn. Có dây buộc gọn sau khi sử dụng.",
    details: ["Kích thước 183 × 61 cm", "Độ dày 6 mm", "Kèm dây buộc"],
    maxQuantity: 10,
  },
  {
    id: "bag",
    name: "Túi thể thao Daily",
    category: "Phụ kiện",
    price: 329000,
    color: "#dce5e6",
    type: "bag",
    label: "SẴN SÀNG ĐI TẬP",
    description: "Túi đựng trang phục và vật dụng cần thiết cho một buổi tập.",
    details: [
      "Kích thước 45 × 24 × 24 cm",
      "Quai xách và dây đeo",
      "Ngăn phụ có khóa kéo",
    ],
    maxQuantity: 10,
  },
  {
    id: "rope",
    name: "Dây nhảy Speed",
    category: "Dụng cụ",
    price: 99000,
    color: "#eadbd4",
    type: "rope",
    label: "CARDIO",
    description:
      "Dây nhảy cho bài khởi động và tập cardio, có thể điều chỉnh độ dài.",
    details: ["Dây dài tối đa 3 m", "Hai tay cầm", "Chiều dài điều chỉnh được"],
    maxQuantity: 10,
  },
  {
    id: "towel",
    name: "Khăn tập Soft",
    category: "Phụ kiện",
    price: 89000,
    color: "#e5e8db",
    type: "towel",
    label: "GỌN NHẸ",
    description: "Khăn nhỏ mang theo khi tập, dễ gấp và cất trong túi.",
    details: [
      "Kích thước 35 × 75 cm",
      "Màu kem",
      "Giặt riêng trước lần sử dụng đầu",
    ],
    maxQuantity: 10,
  },
];
export const money = (value) =>
  new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
    value,
  );
export function createSampleMembers() {
  return [
    { id: 1, name: "Nguyễn Minh Anh", packageName: "Basic" },
    { id: 2, name: "Trần Hoàng Nam", packageName: "Plus" },
    { id: 3, name: "Lê Thảo Vy", packageName: "Pro" },
  ];
}
