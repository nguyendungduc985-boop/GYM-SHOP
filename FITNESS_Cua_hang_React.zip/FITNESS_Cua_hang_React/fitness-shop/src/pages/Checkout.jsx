import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { money } from "../data";
import { getCheckoutLines, orderTotal, validateCustomer } from "../shopLogic";
export default function Checkout({ cart, onCreateOrder, sandbox }) {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const [customer, setCustomer] = useState({ name: "", phone: "", note: "" });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const packageId = params.get("goi") || "";
  const lines = getCheckoutLines(cart, packageId);
  function change(e) {
    setCustomer({ ...customer, [e.target.name]: e.target.value });
  }
  function submit(e) {
    e.preventDefault();
    if (submitting) return;
    const validation = validateCustomer(customer);
    if (validation) return setError(validation);
    setSubmitting(true);
    const result = onCreateOrder(customer, packageId);
    if (!result.ok) {
      setError(result.message);
      setSubmitting(false);
      return;
    }
    navigate("/don-hang/" + result.id);
  }
  if (sandbox)
    return (
      <div className="empty-state">
        <h1>Thanh toán chuyển khoản</h1>
        <p>
          Thoát Sandbox bằng nút cuối trang để sử dụng thông tin nhận tiền thật.
        </p>
      </div>
    );
  if (!lines.length)
    return (
      <div className="empty-state">
        <h1>{packageId ? "Gói tập không tồn tại" : "Giỏ hàng đang trống"}</h1>
        <Link
          className="button primary"
          to={packageId ? "/goi-tap" : "/cua-hang"}
        >
          Quay lại lựa chọn
        </Link>
      </div>
    );
  return (
    <section className="section">
      <div className="page-heading">
        <div className="eyebrow">FITNESS / THANH TOÁN</div>
        <h1>Hoàn tất thông tin.</h1>
        <p>Tạo đơn trên thiết bị này để lấy mã chuyển khoản.</p>
      </div>
      <form className="checkout-grid" onSubmit={submit}>
        <div className="form-panel">
          <h2>Thông tin người đăng ký</h2>
          <label>
            Họ và tên
            <input
              name="name"
              value={customer.name}
              onChange={change}
              required
              maxLength={80}
              autoComplete="name"
            />
          </label>
          <label>
            Số điện thoại
            <input
              name="phone"
              value={customer.phone}
              onChange={change}
              required
              type="tel"
              maxLength={10}
              autoComplete="tel"
            />
          </label>
          <label>
            Ghi chú
            <textarea
              name="note"
              value={customer.note}
              onChange={change}
              rows={3}
              maxLength={300}
              placeholder="Thông tin cần lưu cùng đơn hàng"
            />
          </label>
          <p className="subtle">
            {packageId
              ? "Gói tập được kích hoạt sau khi phòng tập đối chiếu tiền nhận được."
              : "Nhận hàng trực tiếp tại phòng tập sau khi nhân viên xác nhận đơn."}
          </p>
          <p className="notice">
            Đơn lưu trên trình duyệt của bạn, chưa tự gửi đến người bán. Hãy tải
            hoặc gửi thông tin đơn cho nhân viên phòng tập để xác nhận hàng và
            thanh toán.
          </p>
          {error && (
            <p role="alert" className="form-error">
              {error}
            </p>
          )}
        </div>
        <aside className="order-summary">
          <h2>Đơn hàng của bạn</h2>
          {lines.map((item) => (
            <div className="summary-row" key={item.id}>
              <span>
                {item.name} × {item.quantity}
              </span>
              <strong>{money(item.price * item.quantity)}</strong>
            </div>
          ))}
          <div className="summary-total">
            <span>Tổng cộng</span>
            <strong>{money(orderTotal(lines))}</strong>
          </div>
          <button
            className="primary full-width"
            disabled={submitting}
            type="submit"
          >
            {submitting ? "Đang lưu…" : "Lưu đơn & xem QR →"}
          </button>
          <p className="subtle">Bước này chưa thực hiện chuyển tiền.</p>
        </aside>
      </form>
    </section>
  );
}
