import { useState } from "react";
import { Link } from "react-router-dom";
import { products } from "../data";
import ProductArt from "../components/ProductArt";
import ProductCard from "../components/ProductCard";
export default function Home({ onAdd }) {
  const [message, setMessage] = useState("");
  function add(id) {
    setMessage(onAdd(id).message);
  }
  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow">FITNESS STUDIO / EVERYDAY MOVEMENT</div>
          <h1>
            Tốt hơn
            <br />
            từ <em>hôm nay.</em>
          </h1>
          <p>
            Tập luyện theo cách của bạn. Tìm một lớp tập yêu thích và những vật
            dụng đồng hành mỗi ngày.
          </p>
          <div className="hero-actions">
            <Link className="button primary" to="/goi-tap">
              Khám phá gói tập <span>↗</span>
            </Link>
            <Link className="text-link" to="/cua-hang">
              Ghé cửa hàng →
            </Link>
          </div>
          <div className="hero-caption">
            <span className="small-square" /> Mỗi buổi tập là một bước tiến.
          </div>
        </div>
        <div className="hero-visual">
          <div className="visual-top">
            THE DAILY
            <br />
            ESSENTIALS <span>01 / 06</span>
          </div>
          <ProductArt product={products[1]} />
          <div className="visual-bottom">
            <span>
              MOVE MORE.
              <br />
              <b>FEEL BETTER.</b>
            </span>
            <Link to="/cua-hang/dumbbell" aria-label="Xem tạ tay">
              ↗
            </Link>
          </div>
        </div>
      </section>
      <div className="benefit-strip">
        <span>
          <b>01</b> Gói tập linh hoạt
        </span>
        <span>
          <b>02</b> Lịch lớp hàng tuần
        </span>
        <span>
          <b>03</b> Nhận hàng tại phòng tập
        </span>
      </div>
      <section className="section">
        <div className="section-heading">
          <div>
            <div className="eyebrow">TRANG BỊ CHO BUỔI TẬP</div>
            <h2>Những món đồ thiết yếu.</h2>
          </div>
          <Link className="text-link" to="/cua-hang">
            Tất cả sản phẩm ↗
          </Link>
        </div>
        {message && (
          <p className="notice" role="status">
            {message} <Link to="/gio-hang">Xem giỏ hàng →</Link>
          </p>
        )}
        <div className="product-grid">
          {products.slice(0, 4).map((p) => (
            <ProductCard key={p.id} product={p} onAdd={add} />
          ))}
        </div>
      </section>
      <section className="membership-banner">
        <div>
          <div className="eyebrow">DÀNH THỜI GIAN CHO BẢN THÂN</div>
          <h2>
            Một thói quen mới.
            <br />
            Một phiên bản khỏe hơn.
          </h2>
          <p>Tìm gói tập phù hợp và bắt đầu hành trình của bạn.</p>
        </div>
        <Link to="/goi-tap" className="button light">
          Xem các gói tập ↗
        </Link>
      </section>
    </>
  );
}
