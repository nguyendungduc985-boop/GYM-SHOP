import { Link } from "react-router-dom";
import { packages, money } from "../data";
export default function Packages() {
  return (
    <section className="section">
      <div className="page-heading">
        <div className="eyebrow">FITNESS / MEMBERSHIP</div>
        <h1>Chọn nhịp tập của bạn.</h1>
        <p>Một khởi đầu nhỏ cho một hành trình dài.</p>
      </div>
      <div className="plans-grid">
        {packages.map((p) => (
          <article
            className={"plan-card " + (p.id === "plus" ? "featured" : "")}
            key={p.id}
          >
            <div className="plan-top">
              <span>{p.months} THÁNG</span>
              {p.id === "plus" && <span>GÓI ĐỀ XUẤT</span>}
            </div>
            <h2>{p.name}</h2>
            <p>{p.description}</p>
            <div className="plan-price">{money(p.price)}</div>
            <small>Giá trọn gói</small>
            <ul>
              {p.features.map((f) => (
                <li key={f}>✓ {f}</li>
              ))}
            </ul>
            <Link
              className="button primary full-width"
              to={"/thanh-toan?goi=" + p.id}
            >
              Chọn gói {p.name} ↗
            </Link>
          </article>
        ))}
      </div>
    </section>
  );
}
