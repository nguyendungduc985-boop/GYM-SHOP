import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { products, money } from "../data";
import ProductArt from "../components/ProductArt";
export default function ProductDetail({ onAdd }) {
  const { id } = useParams();
  const product = products.find((p) => p.id === id);
  const [message, setMessage] = useState("");
  if (!product)
    return (
      <div className="empty-state">
        <h1>Không tìm thấy sản phẩm</h1>
        <Link to="/cua-hang">Quay lại cửa hàng</Link>
      </div>
    );
  return (
    <section className="section">
      <Link className="text-link" to="/cua-hang">
        ← Cửa hàng
      </Link>
      <div className="product-detail">
        <ProductArt product={product} />
        <div>
          <div className="eyebrow">{product.category} / FITNESS ESSENTIALS</div>
          <h1>{product.name}</h1>
          <div className="detail-price">{money(product.price)}</div>
          <p>{product.description}</p>
          <ul className="detail-list">
            {product.details.map((d) => (
              <li key={d}>{d}</li>
            ))}
          </ul>
          <button
            className="primary"
            onClick={() => setMessage(onAdd(product.id).message)}
          >
            Thêm vào giỏ hàng +
          </button>
          {message && (
            <p role="status" className="notice">
              {message} <Link to="/gio-hang">Xem giỏ →</Link>
            </p>
          )}
          <p className="subtle">
            Nhận hàng tại phòng tập. Tối đa {product.maxQuantity} sản phẩm cùng
            loại mỗi đơn; đây là giới hạn đặt hàng, không phải tồn kho trực
            tiếp.
          </p>
        </div>
      </div>
    </section>
  );
}
