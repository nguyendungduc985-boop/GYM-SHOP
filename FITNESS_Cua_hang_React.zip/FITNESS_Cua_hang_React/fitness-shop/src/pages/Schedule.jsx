import { useState } from "react";

// DỮ LIỆU LOCAL: lịch mẫu viết trực tiếp trong code.
// Đây là lịch lặp hàng tuần, chưa quản lý từng ngày cụ thể.
const classes = [
  {
    id: 1,
    name: "Yoga cơ bản",
    coach: "Thanh Mai",
    day: "Thứ 2",
    time: "06:00 - 07:00",
    capacity: 15,
  },
  {
    id: 2,
    name: "Tập toàn thân",
    coach: "Minh Quân",
    day: "Thứ 3",
    time: "17:30 - 18:30",
    capacity: 20,
  },
  {
    id: 3,
    name: "Cardio",
    coach: "Quốc Bảo",
    day: "Thứ 5",
    time: "18:00 - 19:00",
    capacity: 15,
  },
  {
    id: 4,
    name: "Zumba",
    coach: "Ngọc Hà",
    day: "Thứ 7",
    time: "08:00 - 09:00",
    capacity: 20,
  },
];

function Schedule({ members, bookings, setBookings }) {
  const [selectedMemberId, setSelectedMemberId] = useState("");
  const [message, setMessage] = useState("");

  // ĐĂNG KÝ LỚP
  function handleRegister(gymClass) {
    if (selectedMemberId === "") {
      setMessage("Vui lòng chọn hội viên trước khi đăng ký.");
      return;
    }

    // Giá trị lấy từ select là chuỗi.
    // String() giúp so sánh được với cả id số và id chuỗi.
    const member = members.find((item) => String(item.id) === selectedMemberId);

    if (!member) {
      setMessage("Không tìm thấy hội viên.");
      return;
    }

    const alreadyRegistered = bookings.some(
      (booking) =>
        booking.classId === gymClass.id && booking.memberId === member.id,
    );

    if (alreadyRegistered) {
      setMessage("Hội viên này đã đăng ký lớp.");
      return;
    }

    const registeredCount = bookings.filter(
      (booking) => booking.classId === gymClass.id,
    ).length;

    if (registeredCount >= gymClass.capacity) {
      setMessage("Lớp đã đủ số lượng đăng ký.");
      return;
    }

    const newBooking = {
      id: crypto.randomUUID(),
      memberId: member.id,
      classId: gymClass.id,
    };

    setBookings((previousBookings) => [...previousBookings, newBooking]);

    setMessage(`Đã đăng ký lớp "${gymClass.name}" cho ${member.name}.`);
  }

  // HỦY ĐĂNG KÝ
  function handleCancel(bookingId) {
    const confirmed = window.confirm(
      "Bạn có chắc muốn hủy đăng ký lớp này không?",
    );

    if (!confirmed) {
      return;
    }

    setBookings((previousBookings) =>
      previousBookings.filter((booking) => booking.id !== bookingId),
    );

    setMessage("Đã hủy đăng ký lớp.");
  }

  // Chỉ hiện đăng ký có hội viên và lớp còn tồn tại.
  const visibleBookings = bookings.filter(
    (booking) =>
      members.some((member) => member.id === booking.memberId) &&
      classes.some((gymClass) => gymClass.id === booking.classId),
  );

  return (
    <section className="schedule-section">
      <h2>Lịch tập FITNESS</h2>

      <p className="schedule-description">
        Lịch lớp lặp lại hàng tuần. Chọn hội viên và đăng ký lớp tập phù hợp.
      </p>

      <div className="schedule-select-box">
        <label htmlFor="schedule-member">Chọn hội viên đăng ký</label>

        <select
          id="schedule-member"
          value={selectedMemberId}
          onChange={(event) => {
            setSelectedMemberId(event.target.value);
            setMessage("");
          }}
        >
          <option value="">-- Chọn hội viên --</option>

          {members.map((member) => (
            <option key={member.id} value={String(member.id)}>
              {member.name}
            </option>
          ))}
        </select>

        {members.length === 0 && (
          <p>Chưa có hội viên. Hãy thêm hội viên ở trang Hội viên.</p>
        )}
      </div>

      {message && (
        <p className="member-message" role="status">
          {message}
        </p>
      )}

      <div className="schedule-grid">
        {classes.map((gymClass) => {
          const registeredCount = visibleBookings.filter(
            (booking) => booking.classId === gymClass.id,
          ).length;

          const isFull = registeredCount >= gymClass.capacity;

          const alreadyRegistered = visibleBookings.some(
            (booking) =>
              booking.classId === gymClass.id &&
              String(booking.memberId) === selectedMemberId,
          );

          return (
            <article className="schedule-card" key={gymClass.id}>
              <span className="schedule-day">{gymClass.day}</span>

              <h3>{gymClass.name}</h3>

              <p>
                <strong>Huấn luyện viên:</strong> {gymClass.coach}
              </p>

              <p>
                <strong>Giờ tập:</strong> {gymClass.time}
              </p>

              <p>
                <strong>Đã đăng ký:</strong> {registeredCount}/
                {gymClass.capacity}
              </p>

              <button
                type="button"
                className="schedule-register-button"
                onClick={() => handleRegister(gymClass)}
                disabled={members.length === 0 || alreadyRegistered || isFull}
              >
                {alreadyRegistered
                  ? "Đã đăng ký"
                  : isFull
                    ? "Lớp đã đầy"
                    : "Đăng ký lớp"}
              </button>
            </article>
          );
        })}
      </div>

      <h3 className="booking-heading">
        Danh sách đăng ký: {visibleBookings.length} lượt
      </h3>

      <div className="members-table-wrapper">
        <table className="members-table">
          <thead>
            <tr>
              <th>STT</th>
              <th>Hội viên</th>
              <th>Lớp tập</th>
              <th>Lịch tập</th>
              <th>Thao tác</th>
            </tr>
          </thead>

          <tbody>
            {visibleBookings.map((booking, index) => {
              const member = members.find(
                (item) => item.id === booking.memberId,
              );

              const gymClass = classes.find(
                (item) => item.id === booking.classId,
              );

              return (
                <tr key={booking.id}>
                  <td>{index + 1}</td>
                  <td>{member.name}</td>
                  <td>{gymClass.name}</td>

                  <td>
                    {gymClass.day}
                    <br />
                    {gymClass.time}
                  </td>

                  <td>
                    <button
                      type="button"
                      className="delete-member-button"
                      onClick={() => handleCancel(booking.id)}
                    >
                      Hủy đăng ký
                    </button>
                  </td>
                </tr>
              );
            })}

            {visibleBookings.length === 0 && (
              <tr>
                <td colSpan={5} className="empty-members">
                  Chưa có đăng ký lớp tập.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

export default Schedule;
