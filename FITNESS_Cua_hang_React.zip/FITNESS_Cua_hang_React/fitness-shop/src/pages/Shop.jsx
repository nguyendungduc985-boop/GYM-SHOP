import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Link } from "react-router-dom";
import { products } from "../data";
import ProductCard from "../components/ProductCard";
export default function Shop({ onAdd }) {
  const [params, setParams] = useSearchParams();
  const [message, setMessage] = useState("");
  const query = params.get("q") || "";
  const category = ["Dụng cụ", "Phụ kiện"].includes(params.get("loai"))
    ? params.get("loai")
    : "Tất cả";
  const sort = ["asc", "desc"].includes(params.get("sapxep"))
    ? params.get("sapxep")
    : "default";
  function update(key, value) {
    const next = new URLSearchParams(params);
    if (!value || value === "Tất cả" || value === "default") next.delete(key);
    else next.set(key, value);
    setParams(next, { replace: true });
  }
  const shown = products.filter(
    (p) =>
      p.name
        .toLocaleLowerCase("vi")
        .includes(query.trim().toLocaleLowerCase("vi")) &&
      (category === "Tất cả" || p.category === category),
  );
  if (sort === "asc") shown.sort((a, b) => a.price - b.price);
  if (sort === "desc") shown.sort((a, b) => b.price - a.price);
  return (
    <section className="section">
      <div className="page-heading">
        <div className="eyebrow">FITNESS / CỬA HÀNG</div>
        <h1>Đủ đồ. Sẵn sàng tập.</h1>
        <p>Phụ kiện và dụng cụ cho nhịp sống năng động.</p>
      </div>
      <div className="shop-toolbar">
        <label className="search-field">
          <span>Tìm sản phẩm</span>
          <input
            type="search"
            value={query}
            onChange={(e) => update("q", e.target.value)}
            placeholder="Bình nước, thảm yoga…"
          />
        </label>
        <label>
          <span>Danh mục</span>
          <select
            value={category}
            onChange={(e) => update("loai", e.target.value)}
          >
            <option>Tất cả</option>
            <option>Dụng cụ</option>
            <option>Phụ kiện</option>
          </select>
        </label>
        <label>
          <span>Sắp xếp</span>
          <select
            value={sort}
            onChange={(e) => update("sapxep", e.target.value)}
          >
            <option value="default">Mặc định</option>
            <option value="asc">Giá thấp đến cao</option>
            <option value="desc">Giá cao đến thấp</option>
          </select>
        </label>
      </div>
      <div className="results-count">{shown.length} sản phẩm</div>
      {message && (
        <p role="status" className="notice">
          {message} <Link to="/gio-hang">Xem giỏ hàng →</Link>
        </p>
      )}
      <div className="product-grid">
        {shown.map((p) => (
          <ProductCard
            key={p.id}
            product={p}
            onAdd={(id) => setMessage(onAdd(id).message)}
          />
        ))}
      </div>
      {shown.length === 0 && (
        <div className="empty-state">
          <h2>Không tìm thấy sản phẩm</h2>
          <p>Thử từ khóa khác hoặc xóa bộ lọc.</p>
          <button onClick={() => setParams({})}>Xóa bộ lọc</button>
        </div>
      )}
    </section>
  );
}
