import { createSampleMembers, products } from "./data.js";
// Hai khóa cũ được giữ nguyên để dùng tiếp dữ liệu bạn đã nhập.
export const KEYS = {
  members: "fitness-members",
  bookings: "fitness-bookings",
  shop: "fitness-shop-v1",
};
const validId = (id) => typeof id === "string" || typeof id === "number";
const isMember = (m) =>
  m &&
  validId(m.id) &&
  typeof m.name === "string" &&
  ["Basic", "Plus", "Pro"].includes(m.packageName);
const isBooking = (b) =>
  b &&
  typeof b.id === "string" &&
  validId(b.memberId) &&
  [1, 2, 3, 4].includes(b.classId);
const isCartItem = (item) => {
  const p = item && products.find((p) => p.id === item.productId);
  return (
    p &&
    Number.isInteger(item.quantity) &&
    item.quantity > 0 &&
    item.quantity <= p.maxQuantity
  );
};
const isOrder = (o) =>
  o &&
  typeof o.id === "string" &&
  typeof o.createdAt === "string" &&
  ["products", "package"].includes(o.kind) &&
  ["awaiting_transfer", "customer_reported", "cancelled"].includes(o.status) &&
  o.customer &&
  typeof o.customer.name === "string" &&
  typeof o.customer.phone === "string" &&
  Array.isArray(o.items) &&
  o.items.length > 0 &&
  o.items.every(
    (i) =>
      i &&
      typeof i.name === "string" &&
      Number.isFinite(i.price) &&
      i.price >= 0 &&
      Number.isInteger(i.quantity) &&
      i.quantity > 0,
  ) &&
  Number.isFinite(o.total) &&
  o.total === o.items.reduce((sum, i) => sum + i.price * i.quantity, 0);
export function createSampleData() {
  return { members: createSampleMembers(), bookings: [], cart: [], orders: [] };
}
export function readLocalData() {
  const errors = [];
  function read(key, fallback, validate) {
    try {
      const raw = localStorage.getItem(key);
      if (raw === null) return fallback;
      const value = JSON.parse(raw);
      if (!validate(value)) throw new Error("Sai cấu trúc dữ liệu");
      return value;
    } catch {
      errors.push(key);
      return fallback;
    }
  }
  const members = read(
    KEYS.members,
    createSampleMembers(),
    (v) => Array.isArray(v) && v.every(isMember),
  );
  const bookings = read(
    KEYS.bookings,
    [],
    (v) => Array.isArray(v) && v.every(isBooking),
  );
  const shop = read(
    KEYS.shop,
    { cart: [], orders: [] },
    (v) =>
      v &&
      Array.isArray(v.cart) &&
      v.cart.every(isCartItem) &&
      new Set(v.cart.map((i) => i.productId)).size === v.cart.length &&
      Array.isArray(v.orders) &&
      v.orders.every(isOrder),
  );
  return {
    data: {
      members,
      bookings: bookings.filter((b) =>
        members.some((m) => m.id === b.memberId),
      ),
      cart: shop.cart,
      orders: shop.orders,
    },
    error: errors.length
      ? "Không đọc được dữ liệu: " +
        errors.join(", ") +
        ". Tạm dừng ghi để giữ bản cũ; xem hướng dẫn khôi phục dữ liệu."
      : "",
  };
}
export function writeLocalData(data) {
  localStorage.setItem(KEYS.members, JSON.stringify(data.members));
  localStorage.setItem(KEYS.bookings, JSON.stringify(data.bookings));
  localStorage.setItem(
    KEYS.shop,
    JSON.stringify({ cart: data.cart, orders: data.orders }),
  );
}
// Lưu cả đơn và giỏ trong cùng một khóa trước khi chuyển đến trang QR.
export function writeShopData(cart, orders) {
  localStorage.setItem(KEYS.shop, JSON.stringify({ cart, orders }));
}
